var express = require('express');
var router = express.Router();

// Provided - do not modify
var credentalsAreValid = function (username, password) {
  return username === 'admin' && password === 'password';
};

// Implement the routes.
router.get('/loginAdmin', function (req, res, next) {
  res.render('login');
});

router.post('/loginAdmin', function (req, res, next) {
  var username = req.body.username;
  var password = req.body.password;

  //not sure about if this is the right way to setup a boolean flag
  req.session.isAuthenticated = credentalsAreValid(username, password);

  if (req.session.isAuthenticated) {
    res.send('Logged in as admin');
  } else {
    res.redirect('/loginAdmin');
  }
});

module.exports = router;
