var express = require('express');
var router = express.Router();
var reviewsDb = require('../db/reviews');

// Implement the routes.

router.get('/all', function (req, res, next) {
	
  reviewsDb.getAllReviews( function (err, reviews) {
    if (err !== null) {
      next(err);
    }

    res.json(reviews);
  });

});

router.get('/search/:className', function (req, res, next) {
  var className = req.params.className;


  reviewsDb.getReviewsByClassName(className, function (err, reviews) {
    if (err !== null) {
      next(err);
    }

    res.json(reviews);
  });
});

module.exports = router;
