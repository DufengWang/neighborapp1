var express = require('express');
var router = express.Router();
var reviewsDb = require('../db/reviews');

// Implement the routes.
// Note: the rating will be passed as a string (req.body.rating).
// Use Number() to transform it to a number before adding it to the database.
router.get('/new', function (req, res, next) {
  res.render('addreview');
});

router.post('/new', function (req, res, next) {

  var className = req.body.className;
  var semester = req.body.semester;
  var rating = Number(req.body.rating);
  var text = req.body.text;

  var reviewData = {className: className, semester: semester, rating: rating, text: text};

  reviewsDb.addReview(reviewData, function (err) {
    if (err !== null) {
      next(err);
    }

    res.send('Review Saved');
  });

});

module.exports = router;
